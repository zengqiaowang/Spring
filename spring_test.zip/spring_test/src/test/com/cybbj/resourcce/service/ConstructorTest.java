/**   
 * 类名：ConstructorTest
 *
 */
package com.cybbj.resourcce.service;

import org.junit.Test;

/** 
 * ConstructorTest: TODO请填写类描述
 * 
 * @version 1.0
 * @author 15989
 * @modified 2016-4-24 v1.0 15989 新建 
 */
public class ConstructorTest {
	
	@Test
	public void testConstructorArg() {
		
	}
}
