/**   
 * 类名：ChildBoss
 *
 */
package com.cybbj.resourcce.bean;

import java.util.ArrayList;
import java.util.List;

/**
 * ChildBoss: TODO请填写类描述
 * 
 * @version 1.0
 * @author 15989
 * @modified 2016-4-25 v1.0 15989 新建
 */
public class ChildBoss {

	private List<String> favorite = new ArrayList<String>();

	public List<String> getFavorite() {
		return favorite;
	}

	public void setFavorite(List<String> favorite) {
		this.favorite = favorite;
	}

}
