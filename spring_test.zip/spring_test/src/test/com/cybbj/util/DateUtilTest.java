/**   
 * 类名：DateUtilTest
 *
 */
package com.cybbj.util;

import org.junit.Test;

/** 
 * DateUtilTest: DateUtil工具类测试
 * 
 * @version 1.0
 * @author 15989
 * @modified 2016-4-15 v1.0 15989 新建 
 */
public class DateUtilTest {
	
	@Test
	public void testGetFormatDateStr() {
		System.out.println(DateUtil.getFormatDateStr());
	}
}
