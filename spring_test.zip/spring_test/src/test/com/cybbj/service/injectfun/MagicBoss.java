/**   
 * 类名：MagicBoss
 *
 */
package com.cybbj.service.injectfun;

import com.cybbj.resourcce.bean.Car;

/** 
 * MagicBoss: lookup方法注入测试
 * 
 * @version 1.0
 * @author 15989
 * @modified 2016-4-25 v1.0 15989 新建 
 */
public interface MagicBoss {
	Car getCar();
}
