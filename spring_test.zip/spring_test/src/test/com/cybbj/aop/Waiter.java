/**   
 * 类名：Waiter
 *
 */
package com.cybbj.aop;

/** 
 * Waiter: TODO请填写类描述
 * 
 * @version 1.0
 * @author 15989
 * @modified 2016-5-4 v1.0 15989 新建 
 */
public interface Waiter {
	
	void greetTo(String name);
	void serveTo(String name);
}
