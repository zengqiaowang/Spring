/**   
 * 类名：Seller
 *
 */
package com.cybbj.aop.aspectj.declareparents;

/** 
 * Seller: TODO请填写类描述
 * 
 * @version 1.0
 * @author 15989
 * @modified 2016-5-12 v1.0 15989 新建 
 */
public interface Seller {
	public void sell(String goods);
	public int sellNum();
}
