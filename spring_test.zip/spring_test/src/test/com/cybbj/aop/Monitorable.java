/**   
 * 类名：Monitorable
 *
 */
package com.cybbj.aop;

/** 
 * Monitorable: TODO请填写类描述
 * 
 * @version 1.0
 * @author 15989
 * @modified 2016-5-6 v1.0 15989 新建 
 */
public interface Monitorable {
	void setMonitorActive(boolean active);
}
