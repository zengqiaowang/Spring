/**   
 * 类名：Seller
 *
 */
package com.cybbj.aop.staticpointcut;

/** 
 * Seller: TODO请填写类描述
 * 
 * @version 1.0
 * @author 15989
 * @modified 2016-5-6 v1.0 15989 新建 
 */
public class Seller {
	public void greetTo(String name) {
		System.out.println(" seller greet to " + name);
	}
}
