/**   
 * 类名：UserDao
 *
 */
package com.cybbj.domain.annotation;

/** 
 * UserDao: TODO请填写类描述
 * 
 * @version 1.0
 * @author 15989
 * @modified 2016-4-27 v1.0 15989 新建 
 */
public class UserDao {

}
